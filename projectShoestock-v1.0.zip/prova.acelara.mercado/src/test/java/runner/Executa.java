package runner;

import org.junit.runner.RunWith;
import org.openqa.selenium.chrome.ChromeDriver;

import conexoes.DriversFactory;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import io.cucumber.junit.CucumberOptions.SnippetType;

/**
 * 
 * @author Diego
 *Classe EXECUTA essa est� responsavel para Executar os seus testes e alem disso alguns metodos no quais sao essenciais para automa��o;
 *
 */
@RunWith(Cucumber.class)
@CucumberOptions(
		
		features = "src/test/resources/features",
		glue = "steps",
		tags = "@Testecompra",
		monochrome = true,
		dryRun = false,
		plugin = {"pretty", "html:target/cucumber-report.html"},
		snippets = SnippetType.CAMELCASE
		)


public class Executa extends DriversFactory {
	
	
	
	public static void abrirNavegador() {
		
		String url = "https://www.shoestock.com.br/";
		String navegador = "Chrome";
		if (navegador.equalsIgnoreCase("Chrome")) {
			
			System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
			driver = new ChromeDriver();
			
		}else {
			
			System.out.println("Selecione o navegador correto");
			
		}
		
		driver.get(url);
		driver.manage().window().maximize();
		
		
		
		
		
	}
	
	public static void fecharNavegador() {
		
		driver.quit();
		
	}



}
