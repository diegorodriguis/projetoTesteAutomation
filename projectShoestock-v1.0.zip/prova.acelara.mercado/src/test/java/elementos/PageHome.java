package elementos;

import org.openqa.selenium.By;

public class PageHome {
	
	private By popup = By.xpath("//div[@class='div-close']/span");
	private By novidades = By.xpath("//a[@id='Novidades']");
	private By ordenar = By.xpath("//a[@qa-automation='search-order-button']");
	private By btnCompra = By.xpath("//button[@id='buy-button-now']");
	private By btncookie = By.xpath("//div[@class='cookie-notification-button']");
	private By tela = By.xpath("//div[text()='CONCORDAR E FECHAR']");
	private By valor = By.xpath("//li[@class='summary__item summary__items__item']");
	private By total = By.xpath("//div[@qa-auto='cart-price']");
	
	
	public By getNovidades() {
		return novidades;
	}
	public By getOrdenar() {
		return ordenar;
	}
	public By getBtnCompra() {
		return btnCompra;
	}
	public By getBtncookie() {
		return btncookie;
	}
	public By getTela() {
		return tela;
	}
	public By getTotal() {
		return total;
	}
	public By getValor() {
		return valor;
	}
	public By getPopup() {
		return popup;
	}
	
	
}
