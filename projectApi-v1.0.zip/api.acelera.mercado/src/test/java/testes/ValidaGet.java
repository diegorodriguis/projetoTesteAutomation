package testes;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class ValidaGet {
	
	Response response =  RestAssured.get("https://reqres.in/api/users/2");
	
	@Test
	public void validarApi() {
		
		System.out.println(response.asPrettyString());
		
	}
	
	@Test
	public void validaStatusCode() {
		
		String line =response.getStatusLine();
		int code = response.getStatusCode();
		assertEquals(200, code);
		System.out.println("*** O status code esperado � "+code+ " o teste passou!! ***");
		System.out.println("*** Para conferirmos o status line � "+line+ " o teste passou!! ***");
		
	}
	
	@Test
	public void validaString() {
		
		String capturada = response.asPrettyString();
		String email = "janet.weaver@reqres.in";
		assertTrue(capturada.contains(email));
		System.out.println("O e-mail capturado foi "+email);
		
	}
	
	@Test
	public void validaString1() {
		Response response =  RestAssured.get("https://reqres.in/api/users/2");
		String body = response.jsonPath().getString("data");
		String email = "janet.weaver@reqres.in";
		System.out.println("O e-mail contains"+body.contains(email));
		
	}

}
