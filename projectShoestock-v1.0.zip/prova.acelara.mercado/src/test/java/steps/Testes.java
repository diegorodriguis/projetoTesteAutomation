package steps;

import elementos.PageHome;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.pt.Dado;
import io.cucumber.java.pt.Entao;
import io.cucumber.java.pt.Quando;
import metodos.Metodos;
import runner.Executa;

/**
 * 
 * @author Diego Class Testes para puxar os metodos e elementos no qual ira usar
 *         para realizar todo o processo do seu teste desde iniciar o browser
 *         ate finalizar o mesmo;
 */

public class Testes {

	Metodos metodos = new Metodos();
	PageHome elPageHome = new PageHome();

	@Before
	public static void iniciarTeste() {

		Executa.abrirNavegador();

	}
	
	@After
	public void fecharNavegador() {
		Executa.fecharNavegador();
		
	}

	@Dado("que clicado em Novidades")
	public void queClicadoEmNovidades() {
		metodos.pausa(2000);
		metodos.clicar(elPageHome.getPopup());
		metodos.clicar(elPageHome.getTela());
		metodos.clicarMenu("Novidades");

	}

	@Quando("adicionado produto no carrinho")
	public void adicionadoProdutoNoCarrinho() {
		metodos.selecionarPorPosicao(6);
		metodos.scroll(0, 300);
		metodos.selecionarSize(37);
		metodos.clicar(elPageHome.getBtnCompra());
	}

	@Entao("valido informacoes de compra")
	public void validoInformacoesDeCompra() {
		metodos.pausa(2000);
		metodos.validar(elPageHome.getValor(), "R$ 199,90");
		metodos.validaUrl("https://www.shoestock.com.br/novo-cart");
		metodos.tirarFoto("Compra Validada com Sucesso");
		
		
	}

}
