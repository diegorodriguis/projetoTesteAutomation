package conexoes;

import org.openqa.selenium.WebDriver;

public class DriversFactory {
	
	public static WebDriver driver;

}
