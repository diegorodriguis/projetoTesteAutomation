package metodos;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import conexoes.DriversFactory;

public class Metodos extends DriversFactory {

	public void clicar(By elemento) {
		try {
			
			driver.findElement(elemento).click();
		

		} catch (Exception e) {
			
			System.out.println("*-----* erro ao clicar *-----*");

		}
		

	}

	public void clicarMenu(String menu) {

		driver.findElement(By.xpath("//a[@id='" + menu + "']")).click();

	}

	public void ordenarPor(String nome) {
		// driver.findElement(By.xpath("//div[@class='content']/a[text()='"+nome+"']")).click();
		driver.findElement(By.xpath("//li//div[@class='content']/a[text()='" + nome + "']")).click();

		try {

			System.out.println("****Ordenado pelo item selecionado correto*****");

		} catch (Exception e) {
			System.out.println("*****Erro ao tirar print da tela****");
			tirarFoto("error");

		}

	}

	public void selecionarPorPosicao(int posicao) {

		driver.findElement(By.xpath("//div[@data-position='" + posicao + "']")).click();

	}

	public void selecionarSize(int size) {

		driver.findElement(By.xpath("//li/a[@data-size='size-" + size + "']")).click();

	}

	public void validar(By elemento, String esperado) {

		String capturado = driver.findElement(elemento).getText();
		assertTrue(capturado.contains(esperado));
		System.out.println("O texto capturado foi " + capturado);

	}

	public void scroll(int n1, int n2) {
		
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(" + n1 + ", " + n2 + ")");

	}

	public void tirarFoto(String evidencia) {

		TakesScreenshot srcShot = (TakesScreenshot) driver;
		File srcFile = srcShot.getScreenshotAs(OutputType.FILE);
		File destFile = new File("./evidencias/" + evidencia + ".png");
		try {
			FileUtils.copyFile(srcFile, destFile);
		} catch (IOException e) {

		}

	}

	public void validaUrl(String urlEsperada) {
		String url = driver.getCurrentUrl();
		assertEquals(urlEsperada, url);
		System.out.println("A url � " + url);

	}

	public void pausa(int tempo) {

		try {
			Thread.sleep(tempo);
		} catch (InterruptedException e) {

		}
	}

}
